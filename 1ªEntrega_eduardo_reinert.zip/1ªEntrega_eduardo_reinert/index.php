<?php
    session_start();
    require_once 'conexao.php';

    if($_SERVER['REQUEST_METHOD']== "POST"){
        $email=$_POST['email'];
        $senha=$_POST['senha'];

        $sql = "SELECT * FROM usuario WHERE email=:email";
        $stmt=$pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $usuario=$stmt->fetch(PDO::FETCH_ASSOC);

        if($usuario && password_verify($senha,$usuario['senha'])){
            //login bem sucedido define variaveis de sessao
            $_SESSION['usuario']=$usuario['nome'];
            $_SESSION['perfil']=$usuario['id_perfil'];
            $_SESSION['id_usuario']=$usuario['id_usuario'];

            //verifica se a senha é temporaria
            if($usuario['senha_temporaria']){
                //redireciona para a troca de senha
                header("Location: alterar_senha.php");
                exit();
            } else {
                //redireciona para a pagina principal
                header("Location: principal.php");
                exit();
            }
        } else {
            //login invalido
            echo "<script>alert('E-mail ou senha incorretos');window.location.href='index.php';</script>";
        }
    }

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
    <script src="bootstrap/jquery-3.6.0.js"></script>
    <script src="bootstrap/js/bootstrap.js"></script>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
</head>
<body>
    <h2 align="center">Login</h2>
    <form class="border border-dark-subtle" action="index.php" method="POST">
        <label for="email">E-mail</label>
        <input type="email" id="email" name="email" required>

        <label for="senha">Senha</label>
        <input type="password" id="senha" name="senha" required>

        <button type="submit">Entrar</button>
    </form>

    <p align="center"><a class="btn btn-secondary" role="button" href="recuperar_senha.php">Esqueci a senha</a></p>
    <p align="center">EDUARDO BORSATO REINERT | DESN20242v1</p>
</body>
</html>